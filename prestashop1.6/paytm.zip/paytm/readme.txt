


STEPS TO DEPLOY

1. Create a module in Module section in prestoshop using admin userid and password..
2. Upload the EBS zip file.
3. Enter the secret key , Accout id and mode in confuguration.
4. Verify the ebs module is listed in module section with enable/disable option.
4. Add a career in shipping module.
5. Add a custumer in the custumer section to perform a transaction.
6. Perform a transaction is prestoshop cart using ebs payment option.
7. Verify the transaction is exist in the admin module with transaction id and payment id.
8. Verify the payment id in ebs secure.
